# Change Log
All notable changes to the "vscode-language-pack-zh-hans" language pack will be documented in this file.

## [Released]
* August 8, 2018 - Release for VS Code 1.26
* July 5, 2018 - Release for VS Code 1.25
* June 6, 2018 - Release for VS Code 1.24
* May 5, 2018 - Release for VS Code 1.23
* April 16, 2018 - Initial release
